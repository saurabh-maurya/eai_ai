from pydantic import BaseModel
from typing import List

class TrendingTopic(BaseModel):
    title: str
    url: str

class TrendingResponse(BaseModel):
    topics: List[TrendingTopic]
