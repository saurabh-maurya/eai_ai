from fastapi import APIRouter, HTTPException
from typing import List
from app.services.trending import fetch_trending_topics  # Import your service function
from app.models import TrendingResponse, TrendingTopic  # Import your response models

router = APIRouter()

# Endpoint to get the current trending topics
@router.get("/", response_model=TrendingResponse)
async def get_trending_topics():
    """
    Endpoint to fetch and return the current trending topics.
    """
    try:
        trending_topics = fetch_trending_topics()  # Call the service to fetch trending topics
        return TrendingResponse(topics=trending_topics)  # Return as a response model
    except Exception as e:
        # If something goes wrong, return an HTTP exception with a 500 status code
        raise HTTPException(status_code=500, detail=f"Failed to fetch trending topics: {str(e)}")

# Endpoint to get trending topics for a specific location
@router.get("/location/{woeid}", response_model=TrendingResponse)
async def get_trending_topics_by_location(woeid: int):
    """
    Endpoint to fetch trending topics for a specific location (using WOEID).
    WOEID (Where on Earth ID) is a unique identifier for locations in the Twitter API.
    """
    try:
        trending_topics = fetch_trending_topics(location_woeid=woeid)  # Fetch trending topics by WOEID
        return TrendingResponse(topics=trending_topics)
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to fetch trending topics for location {woeid}: {str(e)}")

