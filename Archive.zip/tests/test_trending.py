print("hello world")
from pytrends.request import TrendReq
from typing import List, Dict
import pandas as pd

def fetch_google_trending_topics(country_code: str = 'US') -> List[Dict[str, str]]:
    """
    Fetch trending topics from Google Trends for a specified country.
    
    Args:
        country_code (str): Two-letter country code (e.g., 'US' for United States, 'GB' for UK).
                            Defaults to 'US'.
    
    Returns:
        List[Dict[str, str]]: A list of dictionaries containing trending topic titles and their traffic.
    """
    try:
        # Initialize pytrends with English language and UTC timezone offset
        pytrends = TrendReq(hl='en-US', tz=360)  # tz=360 is UTC-6, adjust if needed
        
        # Fetch daily trending searches for the specified country
        trending_df = pytrends.trending_searches(pn=country_code.lower())
        
        # Convert DataFrame to a list of dictionaries
        trending_topics = []
        for index, row in trending_df.iterrows():
            topic = {
                'title': row[0],  # The trending search term
                'traffic': 'High'  # Note: pytrends doesn't provide exact traffic numbers
            }
            trending_topics.append(topic)
        
        return trending_topics
    
    except Exception as e:
        print(f"Error fetching trending topics: {e}")
        return []

# Example usage
if __name__ == "__main__":
    trends = fetch_google_trending_topics('US')
    for i, topic in enumerate(trends, 1):
        print(f"{i}. {topic['title']} - Traffic: {topic['traffic']}")