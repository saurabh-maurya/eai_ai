import tweepy
from app.config import TWITTER_API_KEY
from app.models import TrendingTopic
from typing import List

def fetch_trending_topics(location_woeid: int = 1) -> List[TrendingTopic]:
    """
    Fetch trending topics using the Twitter API. 
    By default, it fetches global trends (WOEID 1).
    Pass a WOEID to fetch location-specific trends.
    """
    # Authenticate with Twitter API
    client = tweepy.Client(bearer_token=TWITTER_API_KEY)

    # Fetch trends based on WOEID (default: worldwide WOEID 1)
    trending_data = client.get_place_trends(id=location_woeid)

    # Parse the trending data and return a list of TrendingTopic models
    topics = [
        TrendingTopic(title=topic["name"], url=topic["url"])
        for topic in trending_data[0]["trends"]
    ]

    return topics
